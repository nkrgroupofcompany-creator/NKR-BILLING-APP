# NKR Billing V2.1

Fixed navigation for Billing, Products, Customers and Reports.
Also improved mobile navigation behavior.

Open `index.html` in Chrome/Edge after extracting the ZIP.
